<!DOCTYPE html>
<html lang="en">
<?php include 'header.php';  ?>
<body>




<?php include 'view_info.php';  ?>
    
</body>
</html>